//
//  ViewController.swift
//  tictacetoe_demo
//
//  Created by Misty Liao on 9/27/21.
//

// import packages
import UIKit
import Foundation
// helpful for basic data functionalities; sorting, filtering, date and time calculations

// class declaration example
// can rename if so desired for ease of understanding BUT must be updated in storyboard
class ViewController: UIViewController {
    
    @IBOutlet var buttonCollection: [UIButton]!
    @IBOutlet var textLabel: UILabel!
    
    // set our passcode (this could be done programatically)
    let passcode: String = "9876"
    
    // function that is called once main view of view controller has successfully loaded
    // override is example of overriding initial function of super class to add additional modifications
    override func viewDidLoad() {
        // access same funtions as super class
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        textLabel.text = ""
        
    /* programmatic example
    var label = UILabel(frame: CGRectMake(0, 0, 200, 21))
    label.center = CGPointMake(160, 284)
    label.textAlignment = NSTextAlignment.Center
    label.text = "I'm a test label"
    self.view.addSubview(label)
    */
    }
    
    // setup button functionality
    @IBAction func didClickButton(_ sender: UIButton) {
        if let number = sender.currentTitle, let text = textLabel.text {
            textLabel.text = text + number
        }
    }
    
    @IBAction func resetText(_ sender: UIButton) {
        textLabel.text = ""
        view.backgroundColor = .white
    }
    
    @IBAction func checkText(_ sender: UIButton) {
        if textLabel.text == passcode {
            view.backgroundColor = .green
        } else {
            view.backgroundColor = .red
        }
    }
    
    


}

