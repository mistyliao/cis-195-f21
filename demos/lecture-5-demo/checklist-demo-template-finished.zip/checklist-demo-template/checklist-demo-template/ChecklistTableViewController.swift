//
//  ViewController.swift
//  checklist-demo-template
//
//  Created by Misty Liao on 10/11/21.
//

import UIKit

class ChecklistTableViewController: UITableViewController {

    // TODO: Initialize data source
    var checklistItems = [ChecklistGroup]()
    
    // MARK: Load test data
    override func viewDidLoad() {
        checklistItems.append(ChecklistGroup(title: "Homework", taskList: [ChecklistItem(task: "Do CIS 195"), ChecklistItem(task: "Study for CIS 120"), ChecklistItem(task: "Finish Quad Tree")]))
        
        checklistItems.append(ChecklistGroup(title: "Errands", taskList: [ChecklistItem(task: "Wash the dishes"), ChecklistItem(task: "Buy groceries"), ChecklistItem(task: "Make bed")]))
        
        checklistItems.append(ChecklistGroup(title: "Misc", taskList: [ChecklistItem(task: "Grab dinner"), ChecklistItem(task: "Go to bed early"), ChecklistItem(task: "Hang w friends")]))
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    // MARK: - Implement basic table view methods (delegate and data source)
    override func numberOfSections(in tableView: UITableView) -> Int {
        // TODO: implement
        return checklistItems.count
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // TODO: implement
        return checklistItems[section].taskList.count
    }
    
    //
    override func tableView(_ tableView: UITableView, titleForHeaderInSection
                                section: Int) -> String? {
        // TODO: implement
        return "\(checklistItems[section].title)"
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // TODO: Set reusable cell identifier for dequeueing, update row using index path information and data source
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ChecklistCellIdentifier", for: indexPath) as? ChecklistTableViewCell else {
            fatalError("Unable to dequeue ChecklistTableViewCell")
        }
        // set the task label
        cell.taskLabel.text = checklistItems[indexPath.section].taskList[indexPath.row].task
        
        // set the image of the button based on whether or not the checklist item "isChecked"
        if checklistItems[indexPath.section].taskList[indexPath.row].isChecked {
            cell.checkboxButton.setImage(UIImage(named: "check-box"), for: .normal)
        } else {
            cell.checkboxButton.setImage(UIImage(named: "blank-check-box"), for: .normal)
        }
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        // TODO: implement
        return 50.0
    }
    
    // delegate method for user input
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // MARK: Make sure rows do not stay selected when interacted with
        tableView.deselectRow(at: indexPath, animated: true)
    }

}

struct ChecklistGroup {
    var title: String
    var taskList: [ChecklistItem]
    init(title: String, taskList: [ChecklistItem]) {
        self.title = title
        self.taskList = taskList
    }
}

struct ChecklistItem {
    var task: String
    var isChecked: Bool
    init(task: String) {
        self.task = task
        self.isChecked = false
    }
}

// MARK: Setup Checklist model here (MVC); individual tasks AND groups of tasks

