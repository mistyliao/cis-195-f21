//
//  ChecklistTableViewCell.swift
//  checklist-demo-template
//
//  Created by Misty Liao on 10/11/21.
//

import Foundation
import UIKit

class ChecklistTableViewCell: UITableViewCell {
    // MARK: Insert Table View Cell properties and outlets here
    @IBOutlet var taskLabel: UILabel!
    @IBOutlet var checkboxButton: UIButton!
    
    @IBAction func checkboxWasPressed(_ sender: UIButton) {
        if let image = sender.image(for: .normal) {
            if image == UIImage(named: "blank-check-box") {
                sender.setImage(UIImage(named: "check-box"), for: .normal)
            } else {
                sender.setImage(UIImage(named: "blank-check-box"), for: .normal)
            }
        }
    }
}
